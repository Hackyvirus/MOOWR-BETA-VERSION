// function calculateTotal(
//   totalCIF,
//   totalExport,
//   lifeCycle,
//   ExpectedAnnualGrowth
// ) {
//   let dutyToBePaid;
//   if (totalCIF >= totalExport) {
//     return (dutyToBePaid = 0);
//   } else {
//     let MinusValue = totalExport - totalCIF;
//     console.log("MinusValue",MinusValue)
//     let percentage = (MinusValue / totalCIF) * 100;
//             console.log("percentage", percentage);
//     // let E = 0;
//     // let totalBenifit = 0;
//     // let lastNPV = 0;
//     // let npv;
//     // let tempRaw = totalCIF;
//     // for (let i = 0; i < parseFloat((lifeCycle)); i++) {
//     //   totalBenifit = MinusValue
//     //   if (E == 0) {
//     //     E = (percentage) / 100 + 1;
//     //     console.log("E1", E);
//     //   } else {
//     //     // console.log("e BEFORE ", E);
//     //     E = E * ((percentage) / 100 + 1);
//     //     console.log("D2", E);

//     //   }
//     //   npv = totalBenifit / E;
//     //   lastNPV += npv;
  
//     }
//     console.log("0) Raw NPV: ", lastNPV);
//   return lastNPV;
//   }

// }


// let totalValue = calculateTotal(100000000,150000000,10,5)

// console.log("totalValue",totalValue)


let TotalCIF = 100000000
let TotalExport = 10000000 
let totalDutytoBePaid = 0 
let totalCustomDuty = 17000000;

function calculateDuty(TotalCIF,TotalExport,totalDutytoBePaid,totalCustomDuty){
  console.log(TotalCIF,TotalExport,totalDutytoBePaid,totalCustomDuty)
  if(TotalExport>=TotalCIF){
  return (totalDuty = 0)
}else{
  let minusedValue = TotalCIF - TotalExport;
  console.log("minusedValue",minusedValue)
  let percentage = (minusedValue/TotalCIF) * 100;
  console.log("percentage",percentage)
  let duty=totalCustomDuty * percentage/100;
  console.log("Duty",duty)
  let duty2 = 0
  for(let i = 1;i<=10;i++){
   duty2+=duty * ((15/100));
  }
  console.log("Duty2",duty2)
  totalDutytoBePaid = duty2 + duty
  // totalDutytoBePaid = 105
  console.log("totalDutytoBePaid",totalDutytoBePaid)
  // return totalDutytoBePaid;
  let Dair = 0;
  // let Dair = 0;
  // let totalBenifitair = 0;
  let lastNPVrair = 0;
  let npvair = 0;
  for (let i = 0; i < 9; i++) {
    if (Dair == 0) {
      Dair = (9) / 100 + 1;
      // console.log("Dair",Dair)
    } else {
      Dair = Dair * (9 / 100 + 1);
      // console.log("Dair",Dair)
    }
  }
   console.log("Dair",Dair)
    npvair =totalDutytoBePaid / Dair;
    console.log("npvair++",npvair)
    lastNPVrair += npvair;
  console.log("Duty",lastNPVrair)
  return lastNPVrair;
}
}

17611362.566498514

let CD = calculateDuty(TotalCIF,TotalExport,totalDutytoBePaid,totalCustomDuty)

console.log("CD",CD)
